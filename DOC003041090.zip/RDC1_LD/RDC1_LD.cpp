/*
********************************************************************************
* COPYRIGHT(c) ��� ���� � ��ϻ, 2018
* 
* ����������� ����������� ��������������� �� �������� ���� ����� (as is).
* ��� ��������������� �������� ������ �����������.
********************************************************************************
*/



#if ARDUINO >= 100
  #include "Arduino.h"
#else
  #include "WProgram.h"
#endif



#include "RDC1_LD.h"


RDC1_LD::RDC1_LD(uint8_t LatchPin, uint8_t DataPin, uint8_t ClkPin, uint8_t DigCnt)
{
  Init(LatchPin, DataPin, ClkPin, DigCnt);
}

RDC1_LD::RDC1_LD(uint8_t LatchPin, uint8_t DataPin, uint8_t ClkPin, uint8_t BrightPin, uint8_t DigCnt)
{
  Init(LatchPin, DataPin, ClkPin, DigCnt);
  _BrightPin = BrightPin;
}

void RDC1_LD::print(float Value, uint8_t PointDig)
{
  bool PointSym = false;
     
  if (PointDig != 0)
  {
    for(uint8_t i = 0; i < PointDig; i++)
      Value *= 10;
    
    PointSym = true;
  }
  
  int32_t IntValue = (int32_t)Value;
  bool NegativeVal = false;
  if (IntValue < 0)
  {
    NegativeVal = true;
    IntValue *= -1;
  }
  
  uint8_t Digits[_DigCnt];

  for(uint8_t i = 0; i < _DigCnt; i++)
    Digits[i] = pgm_read_byte(&DIGITS[SPACE_INDEX]);
  
  uint8_t i;
  
  for(i = 0; i < _DigCnt; i++)
  {
    Digits[i] = IntValue%10;
    IntValue = (IntValue - Digits[i]) / 10;
    Digits[i] = pgm_read_byte(&DIGITS[Digits[i]]);
    
    if (IntValue == 0)
      break;
  }
  
  if (NegativeVal && (i < (_DigCnt - 1)))
    Digits[i + 1] = pgm_read_byte(&DIGITS[MINUS_INDEX]);
  if (PointSym)
    Digits[PointDig] |= pgm_read_byte(&DIGITS[POINT_INDEX]);
  
  if (_Type == COMMON_ANODE)
  {
    for(i = 0; i < _DigCnt; i++)
      Digits[i] = ~Digits[i];
  }
  
  digitalWrite(_LatchPin, LOW);
  for (i = 0; i < _DigCnt; i++)
    shiftOut(_DataPin, _ClkPin, LSBFIRST, Digits[i]);
  digitalWrite(_LatchPin, HIGH);
}

void RDC1_LD::SetBrightness(uint8_t Brightness)
{
  if (_BrightPin != NO_PIN)
    analogWrite(_BrightPin, (map(Brightness, 0, 100, 255, 0)));
}

void RDC1_LD::SetType(bool Type)
{
  _Type = Type;
}

void RDC1_LD::Init(uint8_t LatchPin, uint8_t DataPin, uint8_t ClkPin, uint8_t DigCnt)
{
  _LatchPin = LatchPin;
  _DataPin = DataPin;
  _ClkPin = ClkPin;
  _DigCnt = DigCnt;
  pinMode(_LatchPin, OUTPUT);
  pinMode(_DataPin, OUTPUT);
  pinMode(_ClkPin, OUTPUT);
}


//RDC1_LD display;
